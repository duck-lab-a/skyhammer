from pathlib import Path
import json,struct,math,subprocess,zipfile,hashlib,collections
R=Path(__file__).resolve().parent;W=R.parents[1];A=R/'assets'
b=(A/'apache.mesh').read_bytes();magic,count=struct.unpack_from('>II',b)
assert magic==0x53484131 and len(b)==8+count*40 and count%3==0
vs=list(struct.iter_unpack('>10f',b[8:]));groups=collections.defaultdict(list)
for v in vs:
    assert all(math.isfinite(x) for x in v)
    assert abs(sum(x*x for x in v[3:6])-1)<1e-5
    assert all(0<=x<=1 for x in v[6:9]);assert v[9] in range(5)
    groups[int(v[9])].append(v)
assert set(groups)==set(range(5))
rig=json.loads((A/'apache-rig.json').read_text())
b=(A/'apache.glb').read_bytes();magic,version,total=struct.unpack_from('<III',b)
assert magic==0x46546c67 and version==2 and total==len(b)
n,tag=struct.unpack_from('<II',b,12);assert tag==0x4e4f534a
g=json.loads(b[20:20+n]);pos=20+n;size,tag=struct.unpack_from('<II',b,pos)
assert tag==0x004e4942;binary=b[pos+8:];assert len(binary)==size
def accessor(i):
    a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];width={'SCALAR':1,'VEC3':3,'VEC4':4}[a['type']]
    assert a['componentType']==5126 and v['byteOffset']+v['byteLength']<=len(binary)
    data=list(struct.iter_unpack('<'+'f'*width,binary[v['byteOffset']:v['byteOffset']+v['byteLength']]))
    assert len(data)==a['count'];assert all(math.isfinite(x) for row in data for x in row)
    return data
for part in range(5):
    prim=g['meshes'][part]['primitives'][0];p=accessor(prim['attributes']['POSITION']);norm=accessor(prim['attributes']['NORMAL']);colour=accessor(prim['attributes']['COLOR_0'])
    pivot=rig['parts'][str(part)]['pivot'];assert len(p)==len(groups[part])
    for v,local,n,c in zip(groups[part],p,norm,colour):
        assert all(abs(v[k]-(local[k]+pivot[k]))<2e-6 for k in range(3))
        assert all(abs(v[k+3]-n[k])<1e-6 for k in range(3))
        assert all(abs(v[k+6]-c[k])<1e-6 for k in range(3))
for ani in g['animations']:
    for s in ani['samplers']:
        ts=accessor(s['input']);qs=accessor(s['output']);assert len(ts)==len(qs)
        assert all(ts[i][0]<ts[i+1][0] for i in range(len(ts)-1))
        assert all(abs(sum(x*x for x in q)-1)<1e-5 for q in qs)
    for c in ani['channels']:assert c['target']['node']<len(g['nodes'])
names={n['name'] for n in g['nodes']};assert set(rig['hardpoints'])<=names
assert not any('uri' in x for x in g['buffers'])
G=Path(r'C:\Program Files (x86)\Steam\steamapps\common\ProjectZomboid');java=G/'jre64/bin/java.exe';classes=R/'classes'
subprocess.run([str(java),'-jar',str(W/'work/ecj-3.43.0.jar'),'-17','-encoding','UTF-8','-d',str(classes),str(R/'integration/ApacheRig.java'),str(R/'integration/ApacheRigTest.java')],check=True)
t=subprocess.run([str(java),'-cp',str(classes),'skyhammer.aircraft.ApacheRigTest'],check=True,capture_output=True,text=True)
assert 'PASS' in t.stdout
report={'triangles':count//3,'vertices':count,'mesh_glb_positions_normals_colours':'PASS','animation_quaternions':'PASS','external_resources':0,'hardpoints':sorted(rig['hardpoints']),'cpu_rig_test':t.stdout.strip(),'gpu_render_log':(R/'render.log').read_text(),'gpu_animation_log':(R/'render-movie.log').read_text(),'in_game_validation':False}
(R/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
files=sorted(A.glob('*'))+sorted((R/'integration').glob('*.java'))+[R/n for n in ['make_apache.py','ApachePreview.java','render.py','validate_package.py','HANDOFF_KO.txt','LICENSE.txt','validation.json','Apache_Turntable.mp4','apache-hero.png','apache-port.png','apache-side.png','apache-top.png','apache-front.png']]
manifest={p.relative_to(R).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(R/'manifest.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(R/'Skyhammer_Apache_3D_Asset_Pack.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in files+[R/'manifest.json']:z.write(p,p.relative_to(R).as_posix())
print(json.dumps({'PASS':True,'triangles':count//3,'zip_bytes':(R/'Skyhammer_Apache_3D_Asset_Pack.zip').stat().st_size,'cpu_rig':t.stdout.strip()},ensure_ascii=False))
