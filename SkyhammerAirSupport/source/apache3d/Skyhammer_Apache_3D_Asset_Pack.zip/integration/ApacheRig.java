package skyhammer.aircraft;

/** Optional CPU-side attachment transforms matching apache.vert exactly.
 * No Viewpoint/ZombieBuddy dependency, no hook, no gameplay/target selection.
 * Model space: X starboard, Y up, Z nose. All angles in radians.
 */
public final class ApacheRig {
    public static final int AIRFRAME=0, MAIN_ROTOR=1, TAIL_ROTOR=2, TURRET_YAW=3, GUN_PITCH=4;
    public record Point(double x,double y,double z) {
        Point plus(Point b){return new Point(x+b.x,y+b.y,z+b.z);}
        Point minus(Point b){return new Point(x-b.x,y-b.y,z-b.z);}
    }
    private static final Point MAIN=new Point(0,2.65,-.45), TAIL=new Point(.48,1.05,-7.15);
    private static final Point YAW=new Point(0,-.73,2.45), PITCH=new Point(0,-1.02,2.45);
    private ApacheRig(){}
    public static Point rotateX(Point p,double a){double c=Math.cos(a),s=Math.sin(a);return new Point(p.x,c*p.y-s*p.z,s*p.y+c*p.z);}
    public static Point rotateY(Point p,double a){double c=Math.cos(a),s=Math.sin(a);return new Point(c*p.x+s*p.z,p.y,-s*p.x+c*p.z);}
    public static Point transform(Point p,int part,double main,double tail,double yaw,double pitch){
        if(part==MAIN_ROTOR)return rotateY(p.minus(MAIN),main).plus(MAIN);
        if(part==TAIL_ROTOR)return rotateX(p.minus(TAIL),tail).plus(TAIL);
        if(part==GUN_PITCH)p=rotateX(p.minus(PITCH),pitch).plus(PITCH);
        if(part==TURRET_YAW||part==GUN_PITCH)p=rotateY(p.minus(YAW),yaw).plus(YAW);
        return p;
    }
    public static Point gunMuzzle(double yaw,double pitch){return transform(new Point(0,-1.07,4.30),GUN_PITCH,0,0,yaw,pitch);}
    public static Point gunDirection(double yaw,double pitch){return rotateY(rotateX(new Point(0,0,1),pitch),yaw);}
    /** port=true is X negative. outer selects the second pod. */
    public static Point rocketMuzzle(boolean port,boolean outer){return new Point((port?-1:1)*(outer?2.67:1.72),-.57,1.02);}
}
