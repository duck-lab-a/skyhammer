package skyhammer.aircraft;
public final class ApacheRigTest {
    static void close(double a,double b){if(Math.abs(a-b)>1e-8)throw new AssertionError(a+" != "+b);}
    static void same(ApacheRig.Point a,ApacheRig.Point b){close(a.x(),b.x());close(a.y(),b.y());close(a.z(),b.z());}
    public static void main(String[]args){
        same(ApacheRig.gunMuzzle(0,0),new ApacheRig.Point(0,-1.07,4.30));
        same(ApacheRig.gunDirection(0,0),new ApacheRig.Point(0,0,1));
        same(ApacheRig.gunDirection(Math.PI/2,0),new ApacheRig.Point(1,0,0));
        same(ApacheRig.gunDirection(0,Math.PI/2),new ApacheRig.Point(0,-1,0));
        same(ApacheRig.transform(new ApacheRig.Point(0,2.65,-.45),1,2,0,0,0),new ApacheRig.Point(0,2.65,-.45));
        same(ApacheRig.transform(new ApacheRig.Point(.48,1.05,-7.15),2,0,3,0,0),new ApacheRig.Point(.48,1.05,-7.15));
        for(double yaw:new double[]{-.8,0,.8})for(double pitch:new double[]{-.1,0,.4}){
            ApacheRig.Point n=ApacheRig.gunDirection(yaw,pitch);close(n.x()*n.x()+n.y()*n.y()+n.z()*n.z(),1);
            ApacheRig.Point a=ApacheRig.transform(new ApacheRig.Point(0,-1.07,3.30),4,0,0,yaw,pitch),b=ApacheRig.gunMuzzle(yaw,pitch);
            same(new ApacheRig.Point(b.x()-a.x(),b.y()-a.y(),b.z()-a.z()),n);
        }
        close(ApacheRig.rocketMuzzle(true,false).x(),-1.72);close(ApacheRig.rocketMuzzle(false,true).x(),2.67);
        System.out.println("PASS: rotor pivots, turret hierarchy, muzzle direction/position, left/right hardpoints.");
    }
}
