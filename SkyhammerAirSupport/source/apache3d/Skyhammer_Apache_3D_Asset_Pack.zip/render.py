from pathlib import Path
import subprocess,os,sys
R=Path(__file__).resolve().parent;W=R.parents[1]
G=Path(r'C:\Program Files (x86)\Steam\steamapps\common\ProjectZomboid');J=G/'jre64/bin/java.exe'
C=R/'classes';C.mkdir(exist_ok=True)
cp=os.pathsep.join(map(str,[G,G/'projectzomboid.jar',C]))
subprocess.run([str(J),'-jar',str(W/'work/ecj-3.43.0.jar'),'-17','-encoding','UTF-8','-cp',cp,'-d',str(C),str(R/'ApachePreview.java')],check=True)
cmd=[str(J),'-Djava.awt.headless=true','--enable-native-access=ALL-UNNAMED','-Dorg.lwjgl.librarypath='+str(G),'-Djava.library.path='+str(G),'-cp',cp,'ApachePreview',str(R)]
if '--movie' in sys.argv:
    ff=W/'work/video-tools/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe'
    with (R/'render-movie.log').open('wb') as log:
        p=subprocess.Popen(cmd+['movie'],cwd=G,stdout=subprocess.PIPE,stderr=log)
        e=subprocess.Popen([str(ff),'-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1440x1000','-r','30','-i','pipe:0','-an','-c:v','libx264','-crf','20','-preset','fast','-threads','4','-pix_fmt','yuv420p',str(R/'Apache_Turntable.mp4')],stdin=p.stdout,stderr=log)
        p.stdout.close();assert e.wait()==0;assert p.wait()==0
else:
    with (R/'render.log').open('w') as log:subprocess.run(cmd,cwd=G,stdout=subprocess.DEVNULL,stderr=log,check=True)
print('RENDERED',R)
