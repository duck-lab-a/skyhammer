"""Original, stylized AH-64D-inspired game art. No downloaded geometry/textures.
Y up, +Z nose, X starboard. Art proportions, not an engineering model.
Outputs vertex-colour OBJ/MTL, animated glTF binary, and Skyhammer SHA1 mesh.
"""
from pathlib import Path
import math,struct,json,collections
R=Path(__file__).resolve().parent; A=R/'assets';A.mkdir(exist_ok=True)
V=[]
GREEN=(.22,.26,.17); EDGE=(.30,.34,.22); DARK=(.095,.11,.085)
GLASS=(.11,.24,.28); METAL=(.22,.23,.21); BLACK=(.035,.04,.035)
LABEL=(.65,.67,.48); LENS=(.16,.33,.37)
PIVOTS={0:(0,0,0),1:(0,2.65,-.45),2:(.48,1.05,-7.15),3:(0,-.73,2.45),4:(0,-1.02,2.45)}
NAMES={0:'airframe',1:'main_rotor',2:'tail_rotor',3:'turret_yaw',4:'gun_pitch'}
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def cross(a,b):return(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def unit(v):
    n=math.sqrt(sum(x*x for x in v));return tuple(x/n for x in v)
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def tri(a,b,c,col=GREEN,part=0):
    n=cross(sub(b,a),sub(c,a))
    if sum(x*x for x in n)<1e-16:return
    n=unit(n)
    for p in (a,b,c):V.append((*p,*n,*col,float(part)))
def quad(a,b,c,d,col=GREEN,part=0):tri(a,b,c,col,part);tri(a,c,d,col,part)
def box(center,size,col=GREEN,part=0):
    x,y,z=center;dx,dy,dz=[s/2 for s in size]
    p=[(x+a*dx,y+b*dy,z+c*dz) for a,b,c in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
    for ids in [(0,3,2,1),(4,5,6,7),(0,4,7,3),(1,2,6,5),(3,7,6,2),(0,1,5,4)]:quad(*(p[i] for i in ids),col,part)
def rod(a,b,r,col=METAL,part=0,sides=8,r2=None):
    axis=unit(sub(b,a));t=unit(cross(axis,(0,1,0) if abs(axis[1])<.95 else (0,0,1)));u=cross(axis,t)
    rings=[]
    for p,rad in [(a,r),(b,r if r2 is None else r2)]:
        rings.append([tuple(p[k]+rad*(math.cos(i*math.tau/sides)*t[k]+math.sin(i*math.tau/sides)*u[k]) for k in range(3)) for i in range(sides)])
    for i in range(sides):
        j=(i+1)%sides;quad(rings[0][i],rings[0][j],rings[1][j],rings[1][i],col,part)
        tri(a,rings[0][j],rings[0][i],col,part);tri(b,rings[1][i],rings[1][j],col,part)
def loft(rings,col=GREEN,sides=10):
    pts=[[(rx*math.cos(i*math.tau/sides),cy+ry*math.sin(i*math.tau/sides),z) for i in range(sides)] for z,rx,ry,cy in rings]
    for a,b in zip(pts,pts[1:]):
        for i in range(sides):quad(a[i],a[(i+1)%sides],b[(i+1)%sides],b[i],col)
    for ring,rev in [(pts[0],True),(pts[-1],False)]:
        c=tuple(sum(p[k] for p in ring)/sides for k in range(3))
        for i in range(sides):tri(c,ring[(i+1)%sides] if rev else ring[i],ring[i] if rev else ring[(i+1)%sides],col)
def slab(poly,thick,col=GREEN,part=0):
    a=[(x,y+thick/2,z) for x,y,z in poly];b=[(x,y-thick/2,z) for x,y,z in poly]
    for i in range(1,len(a)-1):tri(a[0],a[i],a[i+1],col,part);tri(b[0],b[i+1],b[i],col,part)
    for i in range(len(a)):quad(a[i],b[i],b[(i+1)%len(a)],a[(i+1)%len(a)],col,part)
def panel(poly):
    quad(*poly,GLASS)
    for i in range(4):rod(poly[i],poly[(i+1)%4],.035,EDGE,sides=5)
def ellipsoid(c,r,col=GREEN,part=0,sides=12,rows=6):
    pts=[]
    for j in range(rows+1):
        phi=-math.pi/2+math.pi*j/rows
        pts.append([tuple(c[k]+(r[0]*math.cos(phi)*math.cos(i*math.tau/sides),r[1]*math.sin(phi),r[2]*math.cos(phi)*math.sin(i*math.tau/sides))[k] for k in range(3)) for i in range(sides)])
    for a,b in zip(pts,pts[1:]):
        for i in range(sides):quad(a[i],b[i],b[(i+1)%sides],a[(i+1)%sides],col,part)

# Narrow faceted fuselage with a long tapering tail boom.
loft([(-7.9,.07,.12,1.12),(-6.7,.20,.20,.83),(-4.5,.31,.30,.53),(-2.8,.48,.46,.29),(-1.5,.72,.69,.12),(.5,.73,.74,.10),(2,.60,.57,.05),(3.65,.49,.44,.02),(4.45,.29,.29,-.03),(4.70,.11,.17,-.12)])
# Tandem canopy: back seat is distinctly higher than the forward gunner's seat.
for sign in [-1,1]:
    panel([(sign*.51,.48,.25),(sign*.40,1.60,.55),(sign*.37,1.48,1.72),(sign*.61,.48,1.91)])
    panel([(sign*.61,.46,1.96),(sign*.37,1.42,1.83),(sign*.32,1.05,3.20),(sign*.50,.35,3.52)])
    panel([(sign*.045,1.07,3.21),(sign*.32,1.05,3.20),(sign*.49,.40,3.59),(sign*.045,.46,3.79)])
    rod((sign*.58,.43,.20),(sign*.49,.35,3.55),.045,EDGE)
quad((-.40,1.61,.54),(.40,1.61,.54),(.37,1.49,1.72),(-.37,1.49,1.72),GREEN)
quad((-.37,1.44,1.83),(.37,1.44,1.83),(.32,1.07,3.2),(-.32,1.07,3.2),GREEN)
# Rear canopy bulkhead and transmission cowling.
box((0,1.14,-.02),(.88,.62,.55));ellipsoid((0,1.37,-1.1),(.68,.58,1.18))
for sign in [-1,1]:
    x=sign*.91
    # External turbine nacelles, dark inlet lips and rear exhaust suppressors.
    rod((x,.80,-3.06),(x,.92,.10),.39,GREEN,sides=12,r2=.40)
    rod((x,.93,.11),(x,.93,.19),.34,METAL,sides=12)
    rod((x,.93,.20),(x,.93,.205),.28,BLACK,sides=12)
    rod((x,.82,-3.11),(x,.79,-3.62),.33,DARK,sides=10,r2=.28)
    rod((x,.79,-3.635),(x,.79,-3.65),.23,BLACK,sides=10)
    # Longbow avionics cheek fairings and maintenance panels.
    box((sign*.73,-.07,.45),(.20,.58,2.4),EDGE)
    for z in [-1.10,-.86,-.62,-.38]:box((sign*1.308,.83,z),(.018,.18,.06),BLACK)
    for z in [0,.8]:box((sign*.841,-.02,z),(.018,.27,.46),GREEN)
    # Stub wing/pylons. Four rocket pods total; all hardpoints are decorative game assets.
    slab([(sign*.68,.33,1.0),(sign*3.08,.08,.58),(sign*3.08,.08,-.22),(sign*.68,.33,-.45)],.12,EDGE)
    for station,xp in enumerate([1.72,2.67]):
        xp*=sign;box((xp,-.22,.13),(.15,.48,.31),DARK)
        rod((xp,-.57,-.81),(xp,-.57,.97),.32,GREEN,sides=12)
        rod((xp,-.57,.98),(xp,-.57,1.00),.29,METAL,sides=12)
        # Nineteen recessed tube mouths: centre + six + twelve.
        centers=[(0,0)]+[(.11*math.cos(a*math.tau/6),.11*math.sin(a*math.tau/6)) for a in range(6)]+[(.22*math.cos(a*math.tau/12),.22*math.sin(a*math.tau/12)) for a in range(12)]
        for dx,dy in centers:rod((xp+dx,-.57+dy,1.005),(xp+dx,-.57+dy,1.014),.043,BLACK,sides=6)
        for zz in [-.50,.61]:rod((xp,-.57,zz),(xp,-.57,zz+.06),.331,DARK,sides=12)
    # Main fixed landing gear with torque link, wheel/hub and a rear brace.
    rod((sign*.60,-.39,1.12),(sign*1.12,-1.19,1.33),.085,METAL)
    rod((sign*.61,-.35,.30),(sign*1.12,-1.19,1.33),.048,DARK)
    rod((sign*.98,-1.30,1.33),(sign*1.25,-1.30,1.33),.31,BLACK,sides=14)
    rod((sign*1.253,-1.30,1.33),(sign*1.267,-1.30,1.33),.13,METAL,sides=10)
    # Navigation lamp and stub-wingtip caps.
    box((sign*3.075,.11,.11),(.09,.11,.42),DARK)
    box((sign*3.123,.13,.34),(.015,.05,.10),(.55,.09,.06) if sign<0 else (.1,.48,.24))
# Nose sensor housing with inset optical lenses.
ellipsoid((0,-.19,4.47),(.43,.33,.38),DARK)
rod((-.15,-.11,4.77),(-.15,-.11,4.85),.145,METAL,sides=12)
rod((-.15,-.11,4.854),(-.15,-.11,4.856),.11,LENS,sides=12)
rod((.19,-.22,4.77),(.19,-.22,4.85),.11,BLACK,sides=10)
rod((.19,-.22,4.853),(.19,-.22,4.856),.073,(.22,.08,.075),sides=10)
rod((-.39,.42,3.69),(-.50,.51,4.23),.017,METAL,sides=5)
rod((.39,.42,3.69),(.50,.51,4.23),.017,METAL,sides=5)
# Main rotor mast and mushroom Longbow radar, with rotating head/blades below it.
rod((0,1.70,-.45),(0,3.44,-.45),.11,METAL,sides=12)
ellipsoid((0,3.57,-.45),(.84,.23,.84),GREEN,sides=20,rows=6)
rod((0,3.45,-.45),(0,3.56,-.45),.86,DARK,sides=20)
rod((0,2.58,-.45),(0,2.75,-.45),.28,METAL,part=1,sides=12)
for i in range(4):
    a=math.radians(22)+i*math.pi/2
    def rotor(r,t,y=2.65):return (r*math.cos(a)-t*math.sin(a),y,-.45+r*math.sin(a)+t*math.cos(a))
    rod(rotor(.10,0,2.4),rotor(.70,0,2.65),.033,METAL,part=1,sides=6)
    shape=[rotor(.32,-.12),rotor(5.85,-.21,2.59),rotor(7.25,-.35,2.47),rotor(7.26,-.04,2.47),rotor(.72,.13)]
    slab(shape,.035,DARK,1)
    slab([rotor(6.85,-.30,2.478),rotor(7.24,-.345,2.476),rotor(7.245,-.05,2.476),rotor(6.85,-.07,2.478)],.036,LABEL,1)
# Tailplane and swept fin.
for sign in [-1,1]:
    slab([(sign*.10,.82,-5.54),(sign*1.53,.77,-5.96),(sign*1.43,.77,-6.50),(sign*.1,.82,-6.32)],.075,EDGE)
fin=[(-.07,.9,-6.98),(-.07,2.64,-7.40),(-.07,2.73,-7.94),(-.07,.98,-7.69)]
quad(*fin,GREEN);quad(*[(.07,y,z) for _,y,z in fin],GREEN)
for i in range(4):quad(fin[i],(.07,fin[i][1],fin[i][2]),(.07,fin[(i+1)%4][1],fin[(i+1)%4][2]),fin[(i+1)%4],EDGE)
rod((0,1.05,-7.15),(.61,1.05,-7.15),.10,METAL,sides=10)
for angle in [0,55,180,235]:
    a=math.radians(angle)
    def tail(r,t):return(.50,1.05+r*math.cos(a)-t*math.sin(a),-7.15+r*math.sin(a)+t*math.cos(a))
    # Blade thickness along X; normals calculated explicitly.
    p=[tail(.10,-.08),tail(1.27,-.11),tail(1.29,.11),tail(.15,.08)]
    quad(*p,DARK,2);quad(*[(x+.03,y,z) for x,y,z in reversed(p)],DARK,2)
    for i in range(4):quad(p[i],p[(i+1)%4],tuple(v+(.03 if k==0 else 0) for k,v in enumerate(p[(i+1)%4])),tuple(v+(.03 if k==0 else 0) for k,v in enumerate(p[i])),DARK,2)
rod((0,.63,-6.12),(0,-.43,-6.07),.063,METAL)
rod((-.13,-.55,-6.07),(.13,-.55,-6.07),.21,BLACK,sides=12)
# 30mm chin gun. Yaw cradle and pitch receiver are independent animation parts.
rod((0,-.48,2.45),(0,-.86,2.45),.24,METAL,part=3,sides=12)
for x in [-.22,.22]:box((x,-.94,2.45),(.10,.37,.40),GREEN,3)
box((0,-1.06,2.62),(.27,.24,.70),DARK,4)
box((.20,-1.03,2.46),(.17,.22,.28),METAL,4)
rod((0,-1.07,2.91),(0,-1.07,4.25),.057,METAL,4,sides=10)
rod((0,-1.07,3.92),(0,-1.07,4.29),.076,DARK,4,sides=10)
rod((0,-1.07,4.292),(0,-1.07,4.295),.044,BLACK,4,sides=8)
# Small aerials and keel details; no trademark or external texture assets.
rod((0,1.21,-2.65),(0,1.95,-2.92),.015,BLACK,sides=5)
rod((0,.58,-4.12),(0,1.35,-4.38),.012,BLACK,sides=5)
box((0,-.58,-.65),(.30,.20,1.0),DARK)

with (A/'apache.mesh').open('wb') as f:
    f.write(struct.pack('>II',0x53484131,len(V)))
    for v in V:f.write(struct.pack('>10f',*v))
# OBJ carries standard MTL as well as widely supported vertex colours.
materials={tuple(v[6:9]) for v in V};materials={c:'m'+str(i) for i,c in enumerate(sorted(materials))}
out=['# Original Skyhammer AH-64D-inspired art. +Y up, +Z nose.','mtllib apache.mtl']
for v in V:out.append('v '+' '.join(f'{x:.6f}' for x in (*v[:3],*v[6:9])))
for v in V:out.append('vn '+' '.join(f'{x:.6f}' for x in v[3:6]))
prev=None
for i in range(0,len(V),3):
    key=(int(V[i][9]),tuple(V[i][6:9]))
    if key!=prev:out.extend(['g '+NAMES[key[0]],'usemtl '+materials[key[1]]]);prev=key
    out.append('f '+' '.join(f'{j+1}//{j+1}' for j in range(i,i+3)))
(A/'apache.obj').write_text('\n'.join(out)+'\n')
(A/'apache.mtl').write_text('\n'.join('newmtl '+name+'\nKd '+' '.join(map(str,col))+'\nKa 0.08 0.08 0.08\nKs 0.1 0.1 0.1\nNs 24\nd 1\n' for col,name in materials.items()))

hardpoints={'gun_muzzle':{'parent':'gun_pitch','position':[0,-1.07,4.30]},'rocket_port_inner':{'parent':'airframe','position':[-1.72,-.57,1.02]},'rocket_port_outer':{'parent':'airframe','position':[-2.67,-.57,1.02]},'rocket_starboard_inner':{'parent':'airframe','position':[1.72,-.57,1.02]},'rocket_starboard_outer':{'parent':'airframe','position':[2.67,-.57,1.02]}}
contract={'name':'Skyhammer Apache AH-64D inspired','units':'art metres; tune game scale visually','axes':{'up':'+Y','forward':'+Z','starboard':'+X'},'origin':'airframe near rotor-axis ground projection','parts':{str(k):{'name':NAMES[k],'pivot':v,'axis':'+Y' if k in [1,3] else '+X' if k in [2,4] else None} for k,v in PIVOTS.items()},'hardpoints':hardpoints,'triangle_count':len(V)//3,'vertex_count':len(V),'bounds':[[min(v[k] for v in V),max(v[k] for v in V)] for k in range(3)],'behavior_brief':{'escort_seconds':180,'weapons':['30mm chin gun','rockets'],'end':'return to base','implemented_here':False},'mesh_format':{'magic':'0x53484131','header':'big-endian uint32 magic, uint32 vertex count','vertex':'10 big-endian float32: position XYZ, normal XYZ, RGB, part ID','stride_bytes':40},'turret_order':'yaw about turret_yaw pivot after pitch about gun_pitch pivot; apply same transforms to muzzle','animation_note':'Preview rotor speed is slowed for inspection. Runtime speed is chosen by integrator.'}
(A/'apache-rig.json').write_text(json.dumps(contract,indent=2))

# Self-contained glTF 2.0: vertex colours, independent animated nodes, no external URI.
g={'asset':{'version':'2.0','generator':'Skyhammer original procedural model'},'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'name':'Apache_Root','children':[1,2,3,4]}],'meshes':[],'materials':[{'name':'Military matte vertex colour','pbrMetallicRoughness':{'baseColorFactor':[1,1,1,1],'metallicFactor':.12,'roughnessFactor':.72},'doubleSided':True}],'buffers':[{'byteLength':0}],'bufferViews':[],'accessors':[],'animations':[]}
binary=bytearray()
def access(vals,width,kind='VEC3'):
    while len(binary)%4:binary.append(0)
    start=len(binary);flat=[x for row in vals for x in (row if isinstance(row,(list,tuple)) else [row])]
    binary.extend(struct.pack('<'+'f'*len(flat),*flat));view=len(g['bufferViews']);g['bufferViews'].append({'buffer':0,'byteOffset':start,'byteLength':len(binary)-start})
    a={'bufferView':view,'componentType':5126,'count':len(vals),'type':kind}
    a['min']=[min(flat[k::width]) for k in range(width)];a['max']=[max(flat[k::width]) for k in range(width)]
    g['accessors'].append(a);return len(g['accessors'])-1
for part in range(5):
    vs=[v for v in V if int(v[9])==part];pivot=PIVOTS[part]
    p=access([sub(v[:3],pivot) for v in vs],3);n=access([v[3:6] for v in vs],3);c=access([v[6:9] for v in vs],3)
    g['meshes'].append({'name':NAMES[part],'primitives':[{'attributes':{'POSITION':p,'NORMAL':n,'COLOR_0':c},'material':0}]})
    node={'name':NAMES[part],'mesh':part,'translation':list(sub(pivot,PIVOTS[3]) if part==4 else pivot)}
    if part==3:node['children']=[5]
    g['nodes'].append(node)
for name,hp in hardpoints.items():
    part=next(k for k,v in NAMES.items() if v==hp['parent']);idx=len(g['nodes'])
    g['nodes'].append({'name':name,'translation':list(sub(hp['position'],PIVOTS[part]))})
    g['nodes'][part+1].setdefault('children',[]).append(idx)
times=access([0,.25,.5,.75,1],1,'SCALAR');samplers=[];channels=[]
for node,axis,sign in [(2,1,1),(3,0,-1)]:
    q=[]
    for t in [0,.25,.5,.75,1]:
        a=t*math.tau*sign;v=[0,0,0,math.cos(a/2)];v[axis]=math.sin(a/2);q.append(v)
    rot=access(q,4,'VEC4');samplers.append({'input':times,'output':rot,'interpolation':'LINEAR'});channels.append({'sampler':len(samplers)-1,'target':{'node':node,'path':'rotation'}})
g['animations'].append({'name':'Rotors_inspection_loop','samplers':samplers,'channels':channels})
times2=access([0,1,2,3,4],1,'SCALAR');samplers=[];channels=[]
for node,axis,angles in [(4,1,[0,.55,0,-.55,0]),(5,0,[0,.25,.45,.25,0])]:
    qs=[]
    for a in angles:
        q=[0,0,0,math.cos(a/2)];q[axis]=math.sin(a/2);qs.append(q)
    samplers.append({'input':times2,'output':access(qs,4,'VEC4'),'interpolation':'LINEAR'});channels.append({'sampler':len(samplers)-1,'target':{'node':node,'path':'rotation'}})
g['animations'].append({'name':'Turret_inspection_sweep','samplers':samplers,'channels':channels})
g['buffers'][0]['byteLength']=len(binary)
j=json.dumps(g,separators=(',',':')).encode();j+=b' '*((-len(j))%4);binary.extend(b'\0'*((-len(binary))%4))
with (A/'apache.glb').open('wb') as f:f.write(struct.pack('<III',0x46546C67,2,12+8+len(j)+8+len(binary)));f.write(struct.pack('<II',len(j),0x4E4F534A));f.write(j);f.write(struct.pack('<II',len(binary),0x004E4942));f.write(binary)
assert all(math.isfinite(n) for v in V for n in v)
assert set(int(v[9]) for v in V)==set(range(5))
print(json.dumps({'triangles':len(V)//3,'vertices':len(V),'parts':dict(collections.Counter(int(v[9]) for v in V)),'glb_bytes':(A/'apache.glb').stat().st_size,'bounds':contract['bounds']}))
