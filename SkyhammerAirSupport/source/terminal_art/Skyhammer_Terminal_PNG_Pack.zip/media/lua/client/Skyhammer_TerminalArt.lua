-- PNG artwork renderer. Does not replace the terminal, order, or combat logic.
-- Call Draw from SkyhammerAircraftDiagram.draw; return false keeps its line fallback.
SkyhammerTerminalArt = SkyhammerTerminalArt or {}
local A = SkyhammerTerminalArt
local paths = {
    ac130 = 'media/ui/SH_Art_AC130.png',
    apache = 'media/ui/SH_Art_Apache.png',
    b2 = 'media/ui/SH_Art_B2.png',
}
local cached = {}

function A.RegisterTeam(supportKey)
    assert(type(supportKey) == 'string' and supportKey ~= '', 'Use the registered team support key')
    paths[supportKey] = 'media/ui/SH_Art_Team.png'
    cached[supportKey] = nil
end

function A.Draw(panel, kind, x, y, w, h, alpha)
    local path = paths[kind]
    if not path or w <= 0 or h <= 0 then return false end
    local texture = cached[kind]
    if texture == nil then
        texture = getTexture(path)
        cached[kind] = texture or false
    end
    if not texture then return false end
    local iw, ih = texture:getWidth(), texture:getHeight()
    if iw <= 0 or ih <= 0 then return false end
    local scale = math.min(w / iw, h / ih)
    local dw, dh = iw * scale, ih * scale
    -- Art is already colored. White tint avoids multiplying green onto dark shadows.
    panel:drawTextureScaled(texture, x + (w - dw) / 2, y + (h - dh) / 2,
        dw, dh, math.max(0, math.min(1, alpha or 1)), 1, 1, 1)
    return true
end
