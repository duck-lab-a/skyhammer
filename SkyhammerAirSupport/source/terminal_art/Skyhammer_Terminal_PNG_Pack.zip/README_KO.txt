SKYHAMMER 단말기용 투명 PNG 4종

순서: 특수부대 → 아파치 → AC-130 → B-2
내장 이미지 생성 도구로 새로 제작한 에셋입니다. 생성 프롬프트는 prompts.json에 포함했습니다.
배경, 글자, 버튼, 탄약 바가 없는 개별 RGBA PNG입니다.
이 폴더의 media는 모드 42/media에 병합하는 구조이며, 현재 설치본에는 적용하지 않았습니다.

파일
media/ui/SH_Art_Team.png: 5인 특수부대 흉상
media/ui/SH_Art_Apache.png: 아파치
media/ui/SH_Art_AC130.png: AC-130
media/ui/SH_Art_B2.png: B-2
media/lua/client/Skyhammer_TerminalArt.lua: 비율 유지, 최초 로드 후 캐시하는 렌더링 보조 모듈
preview.html: 기존 패널 색상에서 226px 폭으로 표시하는 크기 점검용 페이지

기존 코드에 연결하는 최소 변경
1. Skyhammer_AircraftDiagram.lua에서 require "Skyhammer_TerminalArt"를 추가합니다.
2. 기존 D.draw 함수 맨 앞에 아래 한 줄을 추가합니다.
   if SkyhammerTerminalArt.Draw(panel, kind, x, y, w, h, alpha) then return end
   PNG가 없거나 등록되지 않은 지원은 기존 선 도식으로 자동 복귀합니다.
3. 특수부대 등록 이후 실제 support key로 아래를 호출합니다.
   SkyhammerTerminalArt.RegisterTeam(actualSupportKey)
   team이라는 가칭을 모드의 실제 키로 가정하지 않았습니다.
4. S.ORDER는 모든 지원 등록 후 실제 특수부대 key, apache, ac130, b2 순으로 구성합니다.

레이아웃
기존 artH 상한 72px에서도 비율을 유지해 표시할 수 있습니다.
폭 226px을 채우려면 이 이미지 비율상 높이가 약 95px 필요합니다.
충분한 공간이 있는 경우에만 artH 상한을 96px까지 늘리는 것을 권합니다.
기존 room 계산은 유지하여 짧은 창이나 큰 글꼴에서 버튼과 겹치지 않게 합니다.
글자/번역/탄약/상태/타이머/버튼은 기존 UI에서 계속 그립니다.
이미지 크기를 늘리려고 창 구조, 사격 버튼, 센서 지도 동작을 바꾸지 않습니다.
정교한 원본을 그대로 보존했습니다. 배포용 축소본이 필요하면 알파를 보존하는 별도 텍스처 빌드 단계에서 만드세요.

검증 범위
RGBA 알파 채널과 투명/불투명 픽셀, 이미지 크기, 체크섬을 validation.json에서 확인할 수 있습니다.
브라우저의 단말기 크기 미리보기까지 점검했습니다.
실제 게임에서 Lua 렌더링 모듈을 로드한 검증은 아직 하지 않았습니다.
음성, 3D 월드 모델, 호위/공격 기능을 변경하지 않습니다.
