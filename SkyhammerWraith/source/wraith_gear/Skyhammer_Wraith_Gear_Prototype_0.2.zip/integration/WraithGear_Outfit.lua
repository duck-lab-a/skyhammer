-- Data-only example for a Bandits brain.clothing table.
-- Do not ship this as an automatic spawn hook.
return {
    UnderwearBottom = "Base.Briefs_SmallTrunks_Black",
    Socks = "Base.Socks_Long_Black",
    Boilersuit = "Base.Boilersuit_SWAT",
    TorsoExtraVestBullet = "WraithGear.OperatorSet",
    Hands = "Base.Gloves_LeatherGlovesBlack",
    Knee_Left = "Base.Kneepad_Left_Tactical",
    Knee_Right = "Base.Kneepad_Right_Tactical",
    BeltExtra = "Base.HolsterSimple_Black",
    Shoes = "Base.Shoes_BlackBoots",
}
